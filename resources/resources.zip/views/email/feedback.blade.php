<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Nunu</title>
</head>

<body>
    <h1>This is ninja nunu hishu</h1>
    <p> Name: {{ $name }} </p>
    <p> Email: {{ $email }} </p>
    <p> Comment: {{ $comment }} </p>
</body>

</html>
