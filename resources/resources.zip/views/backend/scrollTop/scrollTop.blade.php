<style>
    i.fas.fa-angle-up {
        position: absolute;
        top: 30%;
        left: 40%;
    }

</style>

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>
