 <!-- Bootstrap core JavaScript-->
 <script src="{{ asset('backend/vendor/jquery/jquery.min.js') }}"></script>
 <script src="{{ asset('backend/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>

 <!-- Core plugin JavaScript-->
 <script src="{{ asset('backend/vendor/jquery-easing/jquery.easing.min.js') }}"></script>

 <!-- Custom scripts for all pages-->
 <script src="{{ asset('backend/js/sb-admin-2.min.js') }}"></script>

 {{-- Noty CSS & JS CDN --}}
 <link rel="stylesheet" href="{{ asset('noty/noty.min.css') }}">
 <script src="{{ asset('noty/noty.js') }}"></script>

 {{-- Data table JS --}}
 <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
