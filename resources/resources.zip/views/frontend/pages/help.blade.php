@extends('layouts.app')

@section('content')
    @include('frontend.banner.banner')

    <section class="page_content help-section1">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    @include('frontend.inc.sidebar')
                </div>
                <div class="col-lg-9">
                    <div class="row right-help-section1">

                        <div class="question">
                            <h6>Cras et mi sed quam efficitur ultrices.</h6>
                        </div>
                        <div class="answercont">
                            <div class="answer">
                                <p>It is a long established fact that a reader will be distracted by the readable content of
                                    a page when looking at its layout. The point of using Lorem Ipsum is that it has a
                                    more-or-less normal distribution of letters, as opposed to using 'Content here, content
                                    here', making it look like readable English.</p>
                            </div>
                        </div>

                        <div class="question">
                            <h6>orem ipsum dolor sit amet, consectetur adipiscing elit.</h6>
                        </div>
                        <div class="answercont">
                            <div class="answer">
                                <p>It is a long established fact that a reader will be distracted by the readable content of
                                    a page when looking at its layout. The point of using Lorem Ipsum is that it has a
                                    more-or-less normal distribution of letters, as opposed to using 'Content here, content
                                    here', making it look like readable English.</p>
                            </div>
                        </div>

                        <div class="question">
                            <h6>orem ipsum dolor sit amet, consectetur adipiscing elit.</h6>
                        </div>
                        <div class="answercont">
                            <div class="answer">
                                <p>It is a long established fact that a reader will be distracted by the readable content of
                                    a page when looking at its layout. The point of using Lorem Ipsum is that it has a
                                    more-or-less normal distribution of letters, as opposed to using 'Content here, content
                                    here', making it look like readable English.</p>
                            </div>
                        </div>

                        <div class="question">
                            <h6>orem ipsum dolor sit amet, consectetur adipiscing elit.</h6>
                        </div>
                        <div class="answercont">
                            <div class="answer">
                                <p>It is a long established fact that a reader will be distracted by the readable content of
                                    a page when looking at its layout. The point of using Lorem Ipsum is that it has a
                                    more-or-less normal distribution of letters, as opposed to using 'Content here, content
                                    here', making it look like readable English.</p>
                            </div>
                        </div>

                        <div class="question">
                            <h6>orem ipsum dolor sit amet, consectetur adipiscing elit.</h6>
                        </div>
                        <div class="answercont">
                            <div class="answer">
                                <p>It is a long established fact that a reader will be distracted by the readable content of
                                    a page when looking at its layout. The point of using Lorem Ipsum is that it has a
                                    more-or-less normal distribution of letters, as opposed to using 'Content here, content
                                    here', making it look like readable English.</p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
