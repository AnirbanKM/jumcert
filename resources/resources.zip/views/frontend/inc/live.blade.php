<div class="right-works-section2 row">
    <div class="col-md-12">
        <div class="embed-responsive embed-responsive-16by9">
            <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/9xwazD5SyVg" frameborder="0"
                allowfullscreen title="YouTube video player">
            </iframe>
        </div>

        <div class="video_info">
            <h3 class="live">
                <img src="{{ asset('frontend/img/sidebar/g2.png') }}" alt="">
                <span>Ralph Edwards</span>
            </h3>
            <ul>
                <li>
                    <a href="#"><i class="fas fa-thumbs-up"></i>5 Likes</a>
                </li>
                <li>
                    <a href="#"> <i class="fas fa-thumbs-down"></i>5 Likes</a>
                </li>
                <li>
                    <a href="#"><i class="fas fa-share-alt"></i>Share</a>
                </li>
            </ul>
        </div>
    </div>
</div>
