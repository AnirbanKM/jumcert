<section class="start_sec d-none">
    <div class="container">
        <h4>Start for your first 7 days</h4>
        <p>
            Ready to watch? Enter your email to create or restart your membership.
        </p>
        <div class="form_sec">
            <form action="#" class="d-flex">
                <input type="text" class="form-control" placeholder="Enter your email address" />
                <button type="submit" class="email_subs">Get Started</button>
            </form>
        </div>
    </div>
</section>
